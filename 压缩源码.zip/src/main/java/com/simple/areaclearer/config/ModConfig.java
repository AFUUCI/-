package com.simple.areaclearer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/** 配置文件，与旧版 AreaClearer 共用 areaclearer.json。 */
public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("areaclearer.json");

    /** 是否允许清除基岩 */
    public boolean breakBedrock = false;
    /** 黑名单：选区清除时不清除这些方块 */
    public Set<String> blacklist = new HashSet<>();
    /** 白名单：非空时选区清除只清除这些方块 */
    public Set<String> whitelist = new HashSet<>();
    /** 选区工具物品 ID */
    public String selectionTool = "minecraft:stick";
    /** 是否必须手持选区工具才能选点 */
    public boolean requireTool = true;
    /** 选区清除单次最大方块数 */
    public int maxBlocks = 1000000;
    /** 是否清除水/岩浆等流体 */
    public boolean clearFluids = true;
    /** 【新增】空旷域 / 清除区域 的边长（区块数，以玩家为中心），默认 17×17 */
    public int zoneSizeChunks = 17;

    public static ModConfig load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH, StandardCharsets.UTF_8);
                ModConfig cfg = GSON.fromJson(json, ModConfig.class);
                if (cfg != null) {
                    cfg.normalize();
                    return cfg;
                }
            }
        } catch (Exception e) {
            // 读不到就用默认值，不阻止游戏启动
        }
        ModConfig cfg = new ModConfig();
        cfg.save();
        return cfg;
    }

    /** 老配置文件可能缺新字段，这里兜底。 */
    private void normalize() {
        if (blacklist == null) blacklist = new HashSet<>();
        if (whitelist == null) whitelist = new HashSet<>();
        if (selectionTool == null || selectionTool.isEmpty()) selectionTool = "minecraft:stick";
        if (maxBlocks < 1) maxBlocks = 1000000;
        if (zoneSizeChunks < 1 || zoneSizeChunks > 64) zoneSizeChunks = 17;
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException e) {
            // 保存失败不影响本次使用
        }
    }

    private static String idOf(Block block) {
        return Registries.BLOCK.getId(block).toString();
    }

    public boolean isBlacklisted(Block block) {
        return blacklist != null && blacklist.contains(idOf(block));
    }

    /** 白名单为空时不限制（全部允许）。 */
    public boolean isWhitelisted(Block block) {
        if (whitelist == null || whitelist.isEmpty()) return true;
        return whitelist.contains(idOf(block));
    }
}
