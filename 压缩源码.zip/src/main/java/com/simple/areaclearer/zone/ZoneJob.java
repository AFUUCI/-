package com.simple.areaclearer.zone;

import com.simple.areaclearer.AreaClearerMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.particle.DustParticleEffect;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.List;

/**
 * 以玩家为中心 N×N 区块的区域任务：逐区块分帧清空（方块变空气、流体清除、
 * 物品/经验球扫掉），避免一次算完把服务器卡死。
 * void 模式额外把最底层铺成基岩地板并清掉所有非玩家实体。
 */
public class ZoneJob {
    private static final ArrayDeque<ZoneJob> QUEUE = new ArrayDeque<>();
    private static final int FLAGS = Block.NOTIFY_NEIGHBORS | Block.NOTIFY_LISTENERS;
    private static final int CHUNKS_PER_TICK = 2;

    public static boolean hasActive() {
        return !QUEUE.isEmpty();
    }

    public static void schedule(ZoneJob job) {
        QUEUE.addLast(job);
    }

    public static void tick(MinecraftServer server) {
        if (QUEUE.isEmpty()) return;
        int size = QUEUE.size();
        for (int i = 0; i < size; i++) {
            ZoneJob job = QUEUE.pollFirst();
            if (job == null) break;
            if (job.advance()) {
                QUEUE.addLast(job);
            } else {
                job.finish();
            }
        }
    }

    /** 在玩家周围画出区域边界的粒子线（青色），让“大小”看得见。 */
    public static void showOutline(ServerWorld world, ServerPlayerEntity player,
                                   int minX, int maxX, int minZ, int maxZ,
                                   int bottomY, int topY) {
        DustParticleEffect dust = new DustParticleEffect(new Vector3f(0.15f, 0.95f, 0.85f), 1.5f);
        int top = topY - 1;
        for (int x = minX; x <= maxX; x += 8) {
            dot(world, player, dust, x, bottomY, minZ);
            dot(world, player, dust, x, bottomY, maxZ);
            dot(world, player, dust, x, top, minZ);
            dot(world, player, dust, x, top, maxZ);
        }
        for (int z = minZ; z <= maxZ; z += 8) {
            dot(world, player, dust, minX, bottomY, z);
            dot(world, player, dust, maxX, bottomY, z);
            dot(world, player, dust, minX, top, z);
            dot(world, player, dust, maxX, top, z);
        }
        for (int y = bottomY; y <= top; y += 16) {
            dot(world, player, dust, minX, y, minZ);
            dot(world, player, dust, maxX, y, minZ);
            dot(world, player, dust, minX, y, maxZ);
            dot(world, player, dust, maxX, y, maxZ);
        }
    }

    private static void dot(ServerWorld world, ServerPlayerEntity player,
                            DustParticleEffect dust, int x, int y, int z) {
        world.spawnParticles(player, dust, true, x + 0.5, y + 0.5, z + 0.5,
                1, 0.0, 0.0, 0.0, 0.0);
    }

    private final ServerWorld world;
    private final ServerPlayerEntity owner;
    private final int minCX, maxCX, minCZ, maxCZ;
    private final int minX, maxX, minZ, maxZ;
    private final boolean makeFloor;
    private final int bottomY;
    private final int height;
    private final int totalChunks;
    private final int radiusChunks;

    private boolean started = false;
    private int curCX, curCZ;
    private long clearedBlocks = 0;
    private int chunksDone = 0;

    public ZoneJob(ServerWorld world, ServerPlayerEntity owner,
                   int minCX, int maxCX, int minCZ, int maxCZ, boolean makeFloor) {
        this.world = world;
        this.owner = owner;
        this.minCX = minCX;
        this.maxCX = maxCX;
        this.minCZ = minCZ;
        this.maxCZ = maxCZ;
        this.makeFloor = makeFloor;
        this.minX = minCX << 4;
        this.maxX = (maxCX << 4) + 15;
        this.minZ = minCZ << 4;
        this.maxZ = (maxCZ << 4) + 15;
        WorldChunk ref = world.getChunk(owner.getBlockPos().getX() >> 4, owner.getBlockPos().getZ() >> 4);
        this.bottomY = ref.getBottomY();
        this.height = ref.getHeight();
        this.totalChunks = (maxCX - minCX + 1) * (maxCZ - minCZ + 1);
        this.radiusChunks = maxCX - minCX;
    }

    /** 返回 true 表示还有区块要做。 */
    private boolean advance() {
        if (!started) {
            started = true;
            curCX = minCX;
            curCZ = minCZ;
        }
        for (int i = 0; i < CHUNKS_PER_TICK; i++) {
            if (curCZ > maxCZ) return false;
            clearChunk(curCX, curCZ);
            curCX++;
            if (curCX > maxCX) {
                curCX = minCX;
                curCZ++;
            }
        }
        sendProgress();
        return curCZ <= maxCZ;
    }

    private void clearChunk(int cx, int cz) {
        WorldChunk chunk = world.getChunk(cx, cz);
        int chunkBottom = chunk.getBottomY();
        ChunkSection[] sections = chunk.getSectionArray();
        int baseX = cx << 4;
        int baseZ = cz << 4;
        BlockPos.Mutable pos = new BlockPos.Mutable();
        BlockState air = Blocks.AIR.getDefaultState();

        for (int i = 0; i < sections.length; i++) {
            ChunkSection section = sections[i];
            if (section == null || section.isEmpty()) continue;
            for (int ly = 0; ly < 16; ly++) {
                int wy = chunkBottom + i * 16 + ly;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        BlockState state = section.getBlockState(lx, ly, lz);
                        if (state.isAir()) continue;
                        pos.set(baseX + lx, wy, baseZ + lz);
                        if (wy == chunkBottom) {
                            if (makeFloor) {
                                // 空旷域：最底层统一铺基岩地板（已是基岩就不动）
                                if (!state.isOf(Blocks.BEDROCK)) {
                                    world.setBlockState(pos, Blocks.BEDROCK.getDefaultState(), FLAGS);
                                    clearedBlocks++;
                                }
                                continue;
                            } else if (state.isOf(Blocks.BEDROCK)
                                    && !AreaClearerMod.CONFIG.breakBedrock) {
                                continue;
                            }
                        }
                        world.setBlockState(pos, air, FLAGS);
                        clearedBlocks++;
                    }
                }
            }
        }
        chunk.setNeedsSaving(true);
        chunksDone++;
    }

    private void finish() {
        int killed = 0;
        Box box = new Box(minX, bottomY, minZ, maxX + 1.0, bottomY + height, maxZ + 1.0);
        List<Entity> targets = world.getOtherEntities(owner, box, this::shouldRemove);
        for (Entity e : targets) {
            e.discard();
            killed++;
        }

        // 把发起者安全落位，然后解除保护
        if (owner.isAlive() && !owner.isDisconnected()) {
            int tx;
            int tz = (int) Math.floor(owner.getZ());
            int ty;
            if (makeFloor) {
                tx = (int) Math.floor(owner.getX());
                ty = bottomY + 1;
            } else {
                tx = minX - 4;
                ty = world.getTopY(Heightmap.Type.MOTION_BLOCKING, tx, tz) + 1;
            }
            owner.setVelocity(Vec3d.ZERO);
            owner.requestTeleport(tx + 0.5, ty, tz + 0.5);
            owner.fallDistance = 0.0F;
            owner.setInvulnerable(false);
        }

        String sizeText = radiusChunks * 2 + 1 + "×" + (radiusChunks * 2 + 1)
                + " 区块（" + (radiusChunks * 2 + 1) * 16 + "×" + (radiusChunks * 2 + 1) * 16 + " 格）";
        Text done = Text.literal("[一键清理] ").formatted(Formatting.GREEN)
                .append(Text.literal("完成！区域 " + sizeText + "，共清除 "
                        + clearedBlocks + " 个方块、" + killed + " 个掉落物/实体。").formatted(Formatting.WHITE))
                .append(Text.literal(makeFloor ? "（空域已铺好基岩地板）" : "（已按开关保留/清除最底层基岩）")
                        .formatted(Formatting.GRAY));
        owner.sendMessage(done, false);
    }

    private boolean shouldRemove(Entity e) {
        if (e instanceof PlayerEntity) return false;
        if (makeFloor) return true; // 空域清场：清掉所有非玩家实体
        return e instanceof ItemEntity || e instanceof ExperienceOrbEntity;
    }

    private void sendProgress() {
        if (owner.isDisconnected()) return;
        int percent = (int) Math.floor(100.0 * chunksDone / Math.max(1, totalChunks));
        Text t = Text.literal("[一键清理] ").formatted(Formatting.GREEN)
                .append(Text.literal("清空中… " + chunksDone + "/" + totalChunks
                        + " 区块（" + percent + "%），已清除 " + clearedBlocks + " 方块")
                        .formatted(Formatting.YELLOW));
        owner.sendMessage(t, true);
    }
}
