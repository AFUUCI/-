package com.simple.areaclearer.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.simple.areaclearer.AreaClearerMod;
import com.simple.areaclearer.config.ModConfig;
import com.simple.areaclearer.zone.ZoneJob;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Set;
import java.util.TreeSet;

/** 命令树：选区清除（原版功能）+ 一键空域 / 一键清除区域 / 大小显示（新增）。 */
public class AreaClearCommand {

    /** 命令前缀，运行时拼出斜杠+命令名。 */
    private static final String CMD = String.valueOf((char) 47) + "ac";

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("ac")
                .executes(AreaClearCommand::help)
                .then(CommandManager.literal("help").executes(AreaClearCommand::help))
                .then(CommandManager.literal("pos1").executes(c -> setPos(c, 1)))
                .then(CommandManager.literal("pos2").executes(c -> setPos(c, 2)))
                .then(CommandManager.literal("clear").executes(AreaClearCommand::clear))
                .then(CommandManager.literal("void")
                        .executes(c -> zone(c, true))
                        .then(CommandManager.argument("chunks", IntegerArgumentType.integer(1, 64))
                                .executes(c -> zone(c, true))))
                .then(CommandManager.literal("wipe")
                        .executes(c -> zone(c, false))
                        .then(CommandManager.argument("chunks", IntegerArgumentType.integer(1, 64))
                                .executes(c -> zone(c, false))))
                .then(CommandManager.literal("show")
                        .executes(c -> show(c, defaultChunks()))
                        .then(CommandManager.argument("chunks", IntegerArgumentType.integer(1, 64))
                                .executes(c -> show(c, IntegerArgumentType.getInteger(c, "chunks")))))
                .then(CommandManager.literal("size")
                        .executes(AreaClearCommand::showSize)
                        .then(CommandManager.argument("chunks", IntegerArgumentType.integer(1, 64))
                                .executes(AreaClearCommand::setSize)))
                .then(CommandManager.literal("bedrock")
                        .executes(c -> showBool(c, "破坏基岩", AreaClearerMod.CONFIG.breakBedrock))
                        .then(CommandManager.argument("value", BoolArgumentType.bool())
                                .executes(c -> {
                                    AreaClearerMod.CONFIG.breakBedrock = BoolArgumentType.getBool(c, "value");
                                    AreaClearerMod.CONFIG.save();
                                    return setBool(c, "破坏基岩", AreaClearerMod.CONFIG.breakBedrock);
                                })))
                .then(CommandManager.literal("clearfluids")
                        .executes(c -> showBool(c, "清除流体(水/岩浆)", AreaClearerMod.CONFIG.clearFluids))
                        .then(CommandManager.argument("value", BoolArgumentType.bool())
                                .executes(c -> {
                                    AreaClearerMod.CONFIG.clearFluids = BoolArgumentType.getBool(c, "value");
                                    AreaClearerMod.CONFIG.save();
                                    return setBool(c, "清除流体(水/岩浆)", AreaClearerMod.CONFIG.clearFluids);
                                })))
                .then(CommandManager.literal("requiretool")
                        .executes(c -> showBool(c, "必须手持工具", AreaClearerMod.CONFIG.requireTool))
                        .then(CommandManager.argument("value", BoolArgumentType.bool())
                                .executes(c -> {
                                    AreaClearerMod.CONFIG.requireTool = BoolArgumentType.getBool(c, "value");
                                    AreaClearerMod.CONFIG.save();
                                    return setBool(c, "必须手持工具", AreaClearerMod.CONFIG.requireTool);
                                })))
                .then(CommandManager.literal("maxblocks")
                        .executes(c -> {
                            feedback(c, Text.literal("单次最大方块数: ").formatted(Formatting.WHITE)
                                    .append(Text.literal(Integer.toString(AreaClearerMod.CONFIG.maxBlocks))
                                            .formatted(Formatting.AQUA)));
                            return 1;
                        })
                        .then(CommandManager.argument("value", IntegerArgumentType.integer(1, 20_000_000))
                                .executes(c -> {
                                    AreaClearerMod.CONFIG.maxBlocks = IntegerArgumentType.getInteger(c, "value");
                                    AreaClearerMod.CONFIG.save();
                                    feedback(c, Text.literal("单次最大方块数已设为: ").formatted(Formatting.WHITE)
                                            .append(Text.literal(Integer.toString(AreaClearerMod.CONFIG.maxBlocks))
                                                    .formatted(Formatting.AQUA))
                                            .append(Text.literal("（已保存）").formatted(Formatting.GRAY)));
                                    return 1;
                                })))
                .then(CommandManager.literal("tool")
                        .executes(c -> {
                            feedback(c, Text.literal("选区工具: ").formatted(Formatting.WHITE)
                                    .append(Text.literal(AreaClearerMod.getSelectionToolName())
                                            .formatted(Formatting.AQUA)));
                            return 1;
                        })
                        .then(CommandManager.argument("item", IdentifierArgumentType.identifier())
                                .executes(c -> {
                                    Identifier id = IdentifierArgumentType.getIdentifier(c, "item");
                                    Item item = Registries.ITEM.get(id);
                                    if (item == null) {
                                        error(c, "无效物品ID: " + id + "（示例: minecraft:wooden_pickaxe）");
                                        return 0;
                                    }
                                    AreaClearerMod.CONFIG.selectionTool = id.toString();
                                    AreaClearerMod.CONFIG.save();
                                    feedback(c, Text.literal("选区工具已设为: ").formatted(Formatting.WHITE)
                                            .append(Text.literal(id.toString()).formatted(Formatting.AQUA))
                                            .append(Text.literal("（已保存）").formatted(Formatting.GRAY)));
                                    return 1;
                                })))
                .then(CommandManager.literal("blacklist")
                        .then(CommandManager.literal("add")
                                .then(CommandManager.argument("block", IdentifierArgumentType.identifier())
                                        .executes(c -> listAdd(c, true))))
                        .then(CommandManager.literal("remove")
                                .then(CommandManager.argument("block", IdentifierArgumentType.identifier())
                                        .executes(c -> listRemove(c, true))))
                        .then(CommandManager.literal("list").executes(c -> listShow(c, true))))
                .then(CommandManager.literal("whitelist")
                        .then(CommandManager.literal("add")
                                .then(CommandManager.argument("block", IdentifierArgumentType.identifier())
                                        .executes(c -> listAdd(c, false))))
                        .then(CommandManager.literal("remove")
                                .then(CommandManager.argument("block", IdentifierArgumentType.identifier())
                                        .executes(c -> listRemove(c, false))))
                        .then(CommandManager.literal("list").executes(c -> listShow(c, false)))));
    }

    // ---------- 基础 ----------

    private static MutableText prefix() {
        return Text.literal("[一键清理] ").formatted(Formatting.GREEN);
    }

    private static void feedback(CommandContext<ServerCommandSource> c, Text body) {
        MutableText t = prefix().append(body);
        c.getSource().sendFeedback(() -> t, false);
    }

    private static void error(CommandContext<ServerCommandSource> c, String plain) {
        c.getSource().sendError(prefix().append(Text.literal(plain).formatted(Formatting.RED)));
    }

    private static ServerPlayerEntity playerOrNull(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity player = c.getSource().getPlayer();
        if (player == null) {
            error(c, "只有玩家可以执行此命令");
        }
        return player;
    }

    private static int defaultChunks() {
        return AreaClearerMod.CONFIG.zoneSizeChunks;
    }

    private static Text boolText(boolean b) {
        return b ? Text.literal("开启").formatted(Formatting.GREEN)
                : Text.literal("关闭").formatted(Formatting.RED);
    }

    private static int showBool(CommandContext<ServerCommandSource> c, String name, boolean value) {
        feedback(c, Text.literal(name + ": ").formatted(Formatting.WHITE).append(boolText(value)));
        return 1;
    }

    private static int setBool(CommandContext<ServerCommandSource> c, String name, boolean value) {
        feedback(c, Text.literal(name + "已设为: ").formatted(Formatting.WHITE)
                .append(boolText(value))
                .append(Text.literal("（已保存）").formatted(Formatting.GRAY)));
        return 1;
    }

    // ---------- 选区（原版功能） ----------

    private static int setPos(CommandContext<ServerCommandSource> c, int which) {
        ServerPlayerEntity player = playerOrNull(c);
        if (player == null) return 0;
        if (AreaClearerMod.CONFIG.requireTool
                && !player.getMainHandStack().isOf(AreaClearerMod.getSelectionToolItem())) {
            error(c, "必须手持 " + AreaClearerMod.getSelectionToolName() + " 才能选点（或用 "
                    + CMD + " requiretool false 关闭限制）");
            return 0;
        }
        AreaClearerMod.setPoint(player, which);
        return 1;
    }

    private static int clear(CommandContext<ServerCommandSource> c) {
        ServerCommandSource src = c.getSource();
        ServerPlayerEntity player = playerOrNull(c);
        if (player == null) return 0;
        ModConfig cfg = AreaClearerMod.CONFIG;
        if (!AreaClearerMod.SELECTIONS.isComplete(player)) {
            error(c, "请先用 " + AreaClearerMod.getSelectionToolName()
                    + " 设置 pos1（左键）和 pos2（潜行右键），或直接用 " + CMD + " void 一键制造空域");
            return 0;
        }
        BlockPos p1 = AreaClearerMod.SELECTIONS.getPos1(player);
        BlockPos p2 = AreaClearerMod.SELECTIONS.getPos2(player);
        int minX = Math.min(p1.getX(), p2.getX()), maxX = Math.max(p1.getX(), p2.getX());
        int minY = Math.min(p1.getY(), p2.getY()), maxY = Math.max(p1.getY(), p2.getY());
        int minZ = Math.min(p1.getZ(), p2.getZ()), maxZ = Math.max(p1.getZ(), p2.getZ());
        long volume = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
        if (volume > cfg.maxBlocks) {
            error(c, "选区过大（" + volume + " 方块），单次上限 " + cfg.maxBlocks
                    + "，请缩小选区或调 " + CMD + " maxblocks");
            return 0;
        }
        ServerWorld world = src.getWorld();
        feedback(c, Text.literal("开始清空 " + volume + " 方块...").formatted(Formatting.YELLOW));
        int flags = Block.NOTIFY_NEIGHBORS | Block.NOTIFY_LISTENERS;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        long removed = 0;
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    pos.set(x, y, z);
                    BlockState state = world.getBlockState(pos);
                    if (state.isAir()) continue;
                    if (!cfg.clearFluids && !state.getFluidState().isEmpty()) continue;
                    Block block = state.getBlock();
                    if (block == Blocks.BEDROCK && !cfg.breakBedrock) continue;
                    if (cfg.isBlacklisted(block)) continue;
                    if (!cfg.isWhitelisted(block)) continue;
                    world.setBlockState(pos, air, flags);
                    removed++;
                    if (removed % 100000 == 0) {
                        final long shown = removed;
                        player.sendMessage(prefix()
                                .append(Text.literal("已清除 " + shown + " 方块...").formatted(Formatting.YELLOW)), true);
                    }
                }
            }
        }
        feedback(c, Text.literal("完成！共清除 " + removed + " 个方块").formatted(Formatting.WHITE));
        return 1;
    }

    // ---------- 新增：一键空域 / 一键清除 / 显示大小 ----------

    private static int zone(CommandContext<ServerCommandSource> c, boolean voidMode) {
        int want;
        try {
            want = IntegerArgumentType.getInteger(c, "chunks");
        } catch (RuntimeException e) {
            want = defaultChunks();
        }
        return runZone(c.getSource(), want, voidMode);
    }

    private static int runZone(ServerCommandSource src, int wantChunks, boolean voidMode) {
        ServerPlayerEntity player = src.getPlayer();
        if (player == null) {
            src.sendError(prefix().append(Text.literal("只有玩家可以执行此命令").formatted(Formatting.RED)));
            return 0;
        }
        if (ZoneJob.hasActive()) {
            src.sendError(prefix().append(Text.literal("已有区域任务进行中，请等待完成").formatted(Formatting.RED)));
            return 0;
        }
        ServerWorld world = src.getWorld();
        int r = Math.max(1, wantChunks) / 2;
        int n = r * 2 + 1;
        int pcx = player.getBlockPos().getX() >> 4;
        int pcz = player.getBlockPos().getZ() >> 4;
        int minCX = pcx - r, maxCX = pcx + r;
        int minCZ = pcz - r, maxCZ = pcz + r;
        int minX = minCX << 4, maxX = (maxCX << 4) + 15;
        int minZ = minCZ << 4, maxZ = (maxCZ << 4) + 15;
        WorldChunk ref = world.getChunk(pcx, pcz);
        int bottomY = ref.getBottomY();
        int topY = bottomY + ref.getHeight();

        reportSize(src, n, minX, maxX, minZ, maxZ, bottomY, topY, wantChunks);
        ZoneJob.showOutline(world, player, minX, maxX, minZ, maxZ, bottomY, topY);

        player.setInvulnerable(true);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 6000, 0));
        ZoneJob.schedule(new ZoneJob(world, player, minCX, maxCX, minCZ, maxCZ, voidMode));
        if (voidMode) {
            src.sendFeedback(() -> prefix()
                    .append(Text.literal("正在制造 " + n + "×" + n + " 区块空域（铺基岩地板）…进度在动作栏")
                            .formatted(Formatting.AQUA)), false);
        } else {
            src.sendFeedback(() -> prefix()
                    .append(Text.literal("正在清除 " + n + "×" + n + " 区块内所有方块/流体/掉落物…进度在动作栏")
                            .formatted(Formatting.LIGHT_PURPLE)), false);
        }
        return 1;
    }

    private static int show(CommandContext<ServerCommandSource> c, int wantChunks) {
        ServerCommandSource src = c.getSource();
        ServerPlayerEntity player = playerOrNull(c);
        if (player == null) return 0;
        ServerWorld world = src.getWorld();
        int r = Math.max(1, wantChunks) / 2;
        int n = r * 2 + 1;
        int pcx = player.getBlockPos().getX() >> 4;
        int pcz = player.getBlockPos().getZ() >> 4;
        int minCX = pcx - r, maxCX = pcx + r;
        int minCZ = pcz - r, maxCZ = pcz + r;
        int minX = minCX << 4, maxX = (maxCX << 4) + 15;
        int minZ = minCZ << 4, maxZ = (maxCZ << 4) + 15;
        WorldChunk ref = world.getChunk(pcx, pcz);
        int bottomY = ref.getBottomY();
        int topY = bottomY + ref.getHeight();
        reportSize(src, n, minX, maxX, minZ, maxZ, bottomY, topY, wantChunks);
        ZoneJob.showOutline(world, player, minX, maxX, minZ, maxZ, bottomY, topY);
        feedback(c, Text.literal("青色粒子框出的就是 " + CMD + " void 与 wipe 的作用范围，这次没有清除任何东西。")
                .formatted(Formatting.GRAY));
        return 1;
    }

    /** “有显示大小”：把区域的区块数/格数/坐标范围全部报出来。 */
    private static void reportSize(ServerCommandSource src, int n,
                                   int minX, int maxX, int minZ, int maxZ,
                                   int bottomY, int topY, int wantChunks) {
        int side = n * 16;
        long total = (long) side * side * (topY - bottomY);
        MutableText line = prefix()
                .append(Text.literal("区域大小: ").formatted(Formatting.WHITE))
                .append(Text.literal(n + "×" + n + " 区块 = " + side + "×" + side + " 格")
                        .formatted(Formatting.AQUA))
                .append(Text.literal("，高 " + (topY - bottomY) + " 格（Y " + bottomY + "~" + (topY - 1) + "）")
                        .formatted(Formatting.WHITE))
                .append(Text.literal("，约 " + String.format("%.1f", total / 1_000_000.0) + " 百万方块")
                        .formatted(Formatting.GRAY));
        MutableText range = prefix()
                .append(Text.literal("范围: ").formatted(Formatting.WHITE))
                .append(Text.literal("X " + minX + " ~ " + maxX + "，Z " + minZ + " ~ " + maxZ)
                        .formatted(Formatting.YELLOW));
        src.sendFeedback(() -> line, false);
        src.sendFeedback(() -> range, false);
        if (n != wantChunks) {
            src.sendFeedback(() -> prefix()
                    .append(Text.literal("（区块数按玩家居中取奇数：" + wantChunks + " → " + n + "×" + n + "）")
                            .formatted(Formatting.GRAY)), false);
        }
    }

    private static int showSize(CommandContext<ServerCommandSource> c) {
        int z = AreaClearerMod.CONFIG.zoneSizeChunks;
        feedback(c, Text.literal("默认区域大小: ").formatted(Formatting.WHITE)
                .append(Text.literal(z + "×" + z + " 区块").formatted(Formatting.AQUA))
                .append(Text.literal("（用 " + CMD + " size 1~64 修改）").formatted(Formatting.GRAY)));
        return 1;
    }

    private static int setSize(CommandContext<ServerCommandSource> c) {
        int v = IntegerArgumentType.getInteger(c, "chunks");
        AreaClearerMod.CONFIG.zoneSizeChunks = v;
        AreaClearerMod.CONFIG.save();
        feedback(c, Text.literal("默认区域大小已设为: ").formatted(Formatting.WHITE)
                .append(Text.literal(v + "×" + v + " 区块").formatted(Formatting.AQUA))
                .append(Text.literal("（已保存）").formatted(Formatting.GRAY)));
        return 1;
    }

    // ---------- 黑白名单 ----------

    private static int listAdd(CommandContext<ServerCommandSource> c, boolean black) {
        Identifier id = IdentifierArgumentType.getIdentifier(c, "block");
        String s = id.toString();
        if (Registries.BLOCK.get(id) == null) {
            error(c, "无效方块ID: " + s + "（示例: minecraft:water）");
            return 0;
        }
        Set<String> set = black ? AreaClearerMod.CONFIG.blacklist : AreaClearerMod.CONFIG.whitelist;
        set.add(s);
        AreaClearerMod.CONFIG.save();
        feedback(c, Text.literal((black ? "已加入黑名单: " : "已加入白名单: ") + s)
                .formatted(Formatting.WHITE)
                .append(Text.literal(black ? "（清除时跳过这些方块）" : "（非空时只清除这些方块）")
                        .formatted(Formatting.GRAY)));
        return 1;
    }

    private static int listRemove(CommandContext<ServerCommandSource> c, boolean black) {
        Identifier id = IdentifierArgumentType.getIdentifier(c, "block");
        String s = id.toString();
        Set<String> set = black ? AreaClearerMod.CONFIG.blacklist : AreaClearerMod.CONFIG.whitelist;
        if (!set.remove(s)) {
            error(c, (black ? "黑名单中不存在: " : "白名单中不存在: ") + s);
            return 0;
        }
        AreaClearerMod.CONFIG.save();
        feedback(c, Text.literal((black ? "已移除黑名单: " : "已移除白名单: ") + s).formatted(Formatting.WHITE));
        return 1;
    }

    private static int listShow(CommandContext<ServerCommandSource> c, boolean black) {
        Set<String> set = black ? AreaClearerMod.CONFIG.blacklist : AreaClearerMod.CONFIG.whitelist;
        if (set == null || set.isEmpty()) {
            feedback(c, Text.literal(black ? "黑名单为空" : "白名单为空（不限制，清除所有符合条件的方块）")
                    .formatted(Formatting.WHITE));
            return 1;
        }
        String name = black ? "黑名单" : "白名单";
        feedback(c, Text.literal(name + " (" + set.size() + (black ? "，不清除):" : "，只清除):"))
                .formatted(Formatting.WHITE));
        for (String id : new TreeSet<>(set)) {
            final String shown = id;
            c.getSource().sendFeedback(() -> Text.literal(" - " + shown).formatted(Formatting.GRAY), false);
        }
        return 1;
    }

    // ---------- 帮助 ----------

    private static int help(CommandContext<ServerCommandSource> c) {
        String[] heads = {
                "===== 一键清理 用法 =====",
                "-- 新增：一键区域（以玩家为中心，带大小显示）--",
        };
        String[][] items = {
                {CMD + " void [区块数]", "一键制造 NxN 区块空域：全高掏空+铺基岩地板，清方块/流体/掉落物/实体"},
                {CMD + " wipe [区块数]", "一键清除 NxN 区块内所有方块、流体、掉落物（保留原底层开关）"},
                {CMD + " show [区块数]", "只显示区域边界（青色粒子），不清除任何东西"},
                {CMD + " size [区块数]", "查看/设置默认大小（当前 " + AreaClearerMod.CONFIG.zoneSizeChunks + "，1~64）"},
                {CMD + " clear", "清空选区（pos1~pos2 长方体）"},
                {CMD + " pos1|pos2", "以脚下设点（或手持工具左键 / 潜行右键）"},
                {CMD + " bedrock [true|false]", "开关破坏基岩"},
                {CMD + " clearfluids [true|false]", "是否清除水/岩浆"},
                {CMD + " maxblocks [数字]", "选区清除单次最大方块数"},
                {CMD + " tool [物品ID]", "设置选区工具（如 minecraft:stick）"},
                {CMD + " requiretool [true|false]", "是否必须手持工具选点"},
                {CMD + " blacklist add|remove|list", "黑名单（清除时跳过）"},
                {CMD + " whitelist add|remove|list", "白名单（非空时只清除这些）"},
        };
        for (String head : heads) {
            final MutableText t = Text.literal(head).formatted(head.startsWith("====") ? Formatting.GREEN : Formatting.AQUA);
            c.getSource().sendFeedback(() -> t, false);
        }
        for (String[] item : items) {
            final MutableText t = Text.literal(item[0]).formatted(Formatting.YELLOW)
                    .append(Text.literal("  " + item[1]).formatted(Formatting.WHITE));
            c.getSource().sendFeedback(() -> t, false);
        }
        final MutableText note = Text.literal("所有修改自动保存到 " + "config" + java.io.File.separator
                + "areaclearer.json").formatted(Formatting.GRAY);
        c.getSource().sendFeedback(() -> note, false);
        return items.length + heads.length + 1;
    }
}
