package com.simple.areaclearer.selection;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 每个玩家的选区两个角点（内存保存，重进游戏需重新选点）。 */
public class SelectionManager {
    private final Map<UUID, BlockPos> pos1Map = new HashMap<>();
    private final Map<UUID, BlockPos> pos2Map = new HashMap<>();

    public void setPos1(PlayerEntity player, BlockPos pos) {
        pos1Map.put(player.getUuid(), pos);
    }

    public void setPos2(PlayerEntity player, BlockPos pos) {
        pos2Map.put(player.getUuid(), pos);
    }

    public BlockPos getPos1(PlayerEntity player) {
        return pos1Map.get(player.getUuid());
    }

    public BlockPos getPos2(PlayerEntity player) {
        return pos2Map.get(player.getUuid());
    }

    public boolean isComplete(PlayerEntity player) {
        return getPos1(player) != null && getPos2(player) != null;
    }
}
