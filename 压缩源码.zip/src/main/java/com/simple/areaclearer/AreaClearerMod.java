package com.simple.areaclearer;

import com.simple.areaclearer.command.AreaClearCommand;
import com.simple.areaclearer.config.ModConfig;
import com.simple.areaclearer.selection.SelectionManager;
import com.simple.areaclearer.zone.ZoneJob;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AreaClearerMod implements ModInitializer {
    public static final String MOD_ID = "areaclearer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final SelectionManager SELECTIONS = new SelectionManager();
    public static ModConfig CONFIG;

    @Override
    public void onInitialize() {
        CONFIG = ModConfig.load();

        CommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess, environment) -> AreaClearCommand.register(dispatcher));
        // 区域任务分帧执行，避免一键清空卡服
        ServerTickEvents.END_SERVER_TICK.register(ZoneJob::tick);

        // 手持选区工具左键方块：以脚下设 pos1
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.isClient || !isSelectionTool(player)) return ActionResult.PASS;
            setPoint(player, 1);
            return ActionResult.SUCCESS;
        });

        // 潜行右键方块：以脚下设 pos2
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient || !player.isSneaking() || !isSelectionTool(player)) return ActionResult.PASS;
            setPoint(player, 2);
            return ActionResult.SUCCESS;
        });

        // 对着空气潜行右键也可以设 pos2
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !player.isSneaking() || !isSelectionTool(player)) {
                return TypedActionResult.pass(stack);
            }
            setPoint(player, 2);
            return TypedActionResult.consume(stack);
        });

        LOGGER.info("一键清理 已加载 tool={}, requireTool={}", CONFIG.selectionTool, CONFIG.requireTool);
    }

    /** which=1 设 pos1，which=2 设 pos2（都取玩家脚下的方块坐标）。 */
    public static void setPoint(PlayerEntity player, int which) {
        BlockPos pos = player.getBlockPos();
        if (which == 1) {
            SELECTIONS.setPos1(player, pos);
        } else {
            SELECTIONS.setPos2(player, pos);
        }
        Text t = Text.literal("[一键清理] ").formatted(Formatting.GREEN)
                .append(Text.literal("pos" + which + " -> ").formatted(Formatting.WHITE))
                .append(Text.literal(fmt(pos)).formatted(Formatting.AQUA));
        player.sendMessage(t, true);
    }

    public static String fmt(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    private static boolean isSelectionTool(PlayerEntity player) {
        if (!CONFIG.requireTool) return true;
        return player.getMainHandStack().isOf(getSelectionToolItem());
    }

    public static Item getSelectionToolItem() {
        Item item = null;
        Identifier id = Identifier.tryParse(CONFIG.selectionTool);
        if (id != null) item = Registries.ITEM.get(id);
        if (item == null) {
            item = Registries.ITEM.get(Identifier.tryParse("minecraft:stick"));
        }
        return item;
    }

    public static String getSelectionToolName() {
        if (!CONFIG.requireTool) return "任何物品/空手";
        Item item = getSelectionToolItem();
        return item == null ? CONFIG.selectionTool : item.getName().getString();
    }
}
